from jose import jwt
from fastapi import FastAPI, HTTPException, UploadFile, Depends, File, Form
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from typing import Optional, List
import os, hashlib, json, base64
from datetime import datetime, timedelta
from contextlib import contextmanager

SECRET_KEY = "uas-kid-secret"
ALGORITHM = "HS256"
TOKEN_EXPIRE_MINUTES = 30
security = HTTPBearer()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
KEYS_FILE = os.path.join(BASE_DIR, "keys.json")
MESSAGES_FILE = os.path.join(BASE_DIR, "messages.json")

def save_key(user_id, public_key):
    try:
        with open(KEYS_FILE, "r") as f:
            data = json.load(f)
    except:
        data = {}

    data[user_id] = public_key

    with open(KEYS_FILE, "w") as f:
        json.dump(data, f)

def save_message(msg):
    try:
        with open(MESSAGES_FILE, "r") as f:
            data = json.load(f)
    except:
        data = []

    data.append(msg)

    with open(MESSAGES_FILE, "w") as f:
        json.dump(data, f)

app = FastAPI(title="Security Service", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
async def health_check():
    return {
        "status": "Security Service is running",
        "timestamp": datetime.now().isoformat()
    }

@app.get("/")
async def get_index() -> dict:
	return {
		"message": "Hello world! Please visit http://localhost:8080/docs for API UI."
	}

@app.post("/login")
def login(user_id: str = Form(...)):
    if user_id not in ALLOWED_USERS:
        raise HTTPException(status_code=403, detail="Invalid user")

    payload = {
        "sub": user_id,
        "exp": datetime.utcnow() + timedelta(minutes=TOKEN_EXPIRE_MINUTES)
    }

    token = jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)

    return {
        "access_token": token,
        "token_type": "bearer"
    }

def verify_token(
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    try:
        payload = jwt.decode(
            credentials.credentials,
            SECRET_KEY,
            algorithms=[ALGORITHM]
        )
        return payload["sub"]
    except Exception:
        raise HTTPException(
            status_code=401,
            detail="Invalid or expired token"
        )

@app.post("/upload-pdf")
async def upload_pdf(file: UploadFile = File(...)):
    fname = file.filename
    ctype = file.content_type
    
    try:
        contents = await file.read()
        with open(fname, "wb") as f:
            f.write(contents)
    
        pdf_hash = hashlib.sha256(contents).hexdigest()
                
    except Exception as e:
        return {
            "message":(e)
        }
    
    return {
        "message": "File uploaded!",
        "filename": fname,
        "hash": pdf_hash,
        "content-type": ctype
    }


ALLOWED_USERS = ["firman"]

KEYS_FILE = "keys.json"


@app.post("/store")
async def store_pubkey(
    user_id: str = Form(...),
    key_file: UploadFile = File(...)
):
    #STATIC ENTRY
    if user_id not in ALLOWED_USERS:
        raise HTTPException(status_code=403, detail="User not allowed")

    #VALIDASI FILE
    if not key_file.filename.endswith(".pem"):
        raise HTTPException(status_code=400, detail="Public key must be .pem")

    #BACA KEY
    key_bytes = await key_file.read()
    key_text = key_bytes.decode()

    #SIMPAN KEY
    data = {}
    if os.path.exists(KEYS_FILE):
        with open(KEYS_FILE, "r") as f:
            data = json.load(f)

    data[user_id] = key_text

    with open(KEYS_FILE, "w") as f:
        json.dump(data, f, indent=2)

    return {
        "status": "success",
        "user": user_id,
        "filename": key_file.filename
    }

@app.post("/verify")
async def verify_signature(
    sender_id: str = Form(...),
    message: str = Form(...),
    signature_b64: str = Form(...)
):
    if not os.path.exists(KEYS_FILE):
        raise HTTPException(status_code=404, detail="Key storage not found")

    with open(KEYS_FILE, "r") as f:
        keys = json.load(f)

    if sender_id not in keys:
        raise HTTPException(status_code=404, detail="Public key not found")

    public_key_pem = keys[sender_id]

    public_key = serialization.load_pem_public_key(
        public_key_pem.encode()
    )

    signature_b64 = signature_b64.strip().replace("\n", "").replace(" ", "")
    signature = base64.b64decode(signature_b64)

    try:
        public_key.verify(signature, message.encode("utf-8"))
        return {"valid": True}
    except Exception:
        return {"valid": False}

    
MESSAGES_FILE = "messages.json"

@app.post("/relay")
async def relay_message(
    user_id: str = Form(...),
    message: str = Form(...),
    session_user: str = Depends(verify_token)
):
    if user_id != session_user:
        raise HTTPException(status_code=403, detail="Session mismatch")

    msg_hash = hashlib.sha256(message.encode()).hexdigest()

    record = {
        "user": user_id,
        "message": message,
        "hash": msg_hash
    }

    data = []
    if os.path.exists(MESSAGES_FILE):
        with open(MESSAGES_FILE, "r") as f:
            data = json.load(f)

    data.append(record)

    with open(MESSAGES_FILE, "w") as f:
        json.dump(data, f, indent=2)

    return {
        "status": "message relayed",
        "hash": msg_hash
    }

@app.post("/store-v2")
async def store_pubkey_v2(
    user_id: str = Form(...),
    algo: str = Form(...),
    key_file: UploadFile = File(...),
    session_user: str = Depends(verify_token)
):
    if user_id != session_user:
        raise HTTPException(status_code=403, detail="Session mismatch")

    if algo not in ["ed25519", "secp256k1"]:
        raise HTTPException(status_code=400, detail="Unsupported algorithm")

    if not key_file.filename.endswith(".pem"):
        raise HTTPException(status_code=400, detail="Key must be .pem")

    key_pem = (await key_file.read()).decode()

    data = {}
    if os.path.exists(KEYS_FILE):
        with open(KEYS_FILE, "r") as f:
            data = json.load(f)

    data[user_id] = {
        "algorithm": algo,
        "public_key": key_pem
    }

    with open(KEYS_FILE, "w") as f:
        json.dump(data, f, indent=2)

    return {
        "status": "stored",
        "user": user_id,
        "algorithm": algo
    }
#(secp256k1)(ed25519)

@app.post("/verify-v2")
async def verify_signature_v2(
    sender_id: str = Form(...),
    message: str = Form(...),
    signature_b64: str = Form(...),
    session_user: str = Depends(verify_token)
):
    if sender_id != session_user:
        raise HTTPException(status_code=403, detail="Session mismatch")

    if not os.path.exists(KEYS_FILE):
        raise HTTPException(status_code=404, detail="Keys not found")

    with open(KEYS_FILE, "r") as f:
        keys = json.load(f)

    if sender_id not in keys:
        raise HTTPException(status_code=404, detail="User not found")

    algo = keys[sender_id]["algorithm"]
    public_key_pem = keys[sender_id]["public_key"]

    public_key = serialization.load_pem_public_key(
        public_key_pem.encode()
    )

    signature = base64.b64decode(
        signature_b64.strip().replace("\n", "")
    )

    try:
        if algo == "ed25519":
            public_key.verify(signature, message.encode())

        elif algo == "secp256k1":
            public_key.verify(
                signature,
                message.encode(),
                ec.ECDSA(hashes.SHA256())
            )

        return {
            "valid": True,
            "algorithm": algo
        }

    except Exception:
        return {
            "valid": False,
            "algorithm": algo
        }

