from cryptography.hazmat.primitives.asymmetric import ec, padding,ed25519
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.backends import default_backend

from cryptography import x509
from cryptography.x509.oid import NameOID
import datetime, base64

from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.hazmat.primitives import serialization

priv_key = ed25519.Ed25519PrivateKey.generate()
pub_key = priv_key.public_key()

with open("priv.pem", "wb") as f:
    f.write(
        priv_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        )
    )

with open("pub.pem", "wb") as f:
    f.write(
        pub_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
    )


#print("[+] Key pair generated (priv.pem & pub.pem)")
with open("priv.pem", "rb") as f:
    priv_key = serialization.load_pem_private_key(
        f.read(),
        password=None
    )

message = "Hello danis".encode("utf-8")
signature = priv_key.sign(message)

signature_b64 = base64.b64encode(signature).decode()
print(signature_b64)
